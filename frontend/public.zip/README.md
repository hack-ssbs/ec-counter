# EC VH Frontend

To get started with frontend development:

```
yarn
yarn dev
```